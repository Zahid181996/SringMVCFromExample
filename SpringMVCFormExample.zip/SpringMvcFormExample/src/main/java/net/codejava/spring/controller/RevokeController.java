package net.codejava.spring.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import net.codejava.spring.Dao.RevokeUserDaoImpl;
import net.codejava.spring.model.RevokeForm;
import net.codejava.spring.model.User;

@Controller
@RequestMapping(value = "/revoke")
public class RevokeController {
@Autowired
	private RevokeUserDaoImpl revokeDao;
	
	public RevokeUserDaoImpl getRevokeDao() {
		System.out.println("getRevokeDao()");
		return revokeDao;
	}

	public void setRevokeDao(RevokeUserDaoImpl revokeDao) {
		System.out.println("setRevokeDao()");
		this.revokeDao = revokeDao;
	}

	@RequestMapping(method = RequestMethod.GET)
	public String displayRevokePage(Map<String, Object> model) {
		
		RevokeForm revokeForm = new RevokeForm();		
		model.put("revokeForm", revokeForm);
		/*
		 * User userForm = new User(); model.put("userForm", userForm);
		 * 
		 * List<String> professionList = new ArrayList<>();
		 * professionList.add("Developer"); professionList.add("Designer");
		 * professionList.add("IT Manager"); model.put("professionList",
		 * professionList);
		 */
		
		return "revoke";
	}
	
	@RequestMapping(method = RequestMethod.POST)
	public String processRevoke(@ModelAttribute("revokeForm") RevokeForm revoke,
			Map<String, Object> model) {
		
		// implement your own registration logic here...
		
		// for testing purpose:
		/*
		 * System.out.println("username: " + user.getUsername());
		 * System.out.println("password: " + user.getPassword());
		 * System.out.println("email: " + user.getEmail());
		 * System.out.println("birth date: " + user.getBirthDate());
		 * System.out.println("profession: " + user.getProfession());
		 */
		//System.out.println("Inside REvoke Process"+ revoke.getName());
		
		
		  // DB Interface Call 0000000
		
		
	
	System.out.println("Inside REvoke Process 1"+ revoke.getName());  
		  int value=revokeDao.insert(revoke);
	System.out.println("Inside REvoke Process 2"+ revoke.getName()); 
		 
		return "RegistrationSuccess";
	}
}
