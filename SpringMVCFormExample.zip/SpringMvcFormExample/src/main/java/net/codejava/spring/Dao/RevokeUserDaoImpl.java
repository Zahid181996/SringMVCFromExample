package net.codejava.spring.Dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import net.codejava.spring.controller.RevokeController;
import net.codejava.spring.model.RevokeForm;
@Repository
public class RevokeUserDaoImpl {
	
	private JdbcTemplate jdbcTemplate;  
	  
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	}  
	  
	public int insert(RevokeForm e){  
	    String query="insert into revokeDB values('"+e.getName()+"','"+e.getDesignation()+"','"+e.getEmail()+"','" +e.getGender()+"','"+e.getOrganization()+"','"+ e.getReason()+"')";
	    System.out.println("Enter");
	    
	    return jdbcTemplate.update(query);  
	    	}  
	/*
	 * public int updateEmployee(Employee e){ String
	 * query="update employee1 set  name='"+e.getName()+"',salary='"+e.getSalary()
	 * +"' where id='"+e.getId()+"' "; return jdbcTemplate.update(query); } public
	 * int deleteEmployee(Employee e){ String
	 * query="delete from employee1 where id='"+e.getId()+"' "; return
	 * jdbcTemplate.update(query);
	 */  
	/* } */
	  
}